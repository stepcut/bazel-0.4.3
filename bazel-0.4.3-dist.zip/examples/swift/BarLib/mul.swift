/// Class used to multiply stuff.
public class Multiplier {
  public init() {}

  public func multiply(_ a: Int, _ b: Int) -> Int {
      return a * b
  }
}
