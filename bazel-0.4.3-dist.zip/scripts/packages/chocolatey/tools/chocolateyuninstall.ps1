write-host @"
bazel is being uninstalled.

You should now:
* Remove "<msys>/usr/bin" from your PATH

Sorry this isn't automatic; there are no helper functions available within chocolatey (as of v0.10.0) to do these steps as part of the uninstall. See:
* https://github.com/chocolatey/choco/issues/310
* https://github.com/chocolatey/package-validator/issues/148
"@
