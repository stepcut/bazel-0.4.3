---
layout: posts
title: Hello World
---

Welcome to the Bazel blog!  We'll be using this forum for news and
announcements.
