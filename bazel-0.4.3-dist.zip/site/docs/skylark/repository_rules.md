---
layout: redirect
redirect: docs/skylark/repository_rules.html
---
